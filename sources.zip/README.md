# CPU simulator written in C++
## Roget Kou - rk16699 - 36695
### Advanced Computer Architecture

- In order to run first build using g++

'''

cd build
make
./cpu_sim {something.asm}

'''
